﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menu : MonoBehaviour
{
    [SerializeField]
    GameObject[] pans;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Select(int _num)
    {
        for(int i = 0; i < pans.Length; i++)
        {
            if(i == _num)
            {
                pans[i].SetActive(true);
            }
            else
            {
                pans[i].SetActive(false);
            }
        }
    }
}
