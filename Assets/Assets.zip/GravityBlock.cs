﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityBlock : Block
{
    GameObject player;
    [SerializeField]
    UnityEngine.UI.Toggle toggle;
    [SerializeField]
    TMPro.TMP_Text text;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SetPlayer(GameObject _player)
    {
        player = _player;
    }

    public override void Play()
    {
        if (toggle.isOn)
            player.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
        else
            player.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
    }

    public void SetBool()
    {
        if(toggle.isOn)
        {
            text.text = "켜기";
        }
        else
        {
            text.text = "끄기";
        }
    }
}
