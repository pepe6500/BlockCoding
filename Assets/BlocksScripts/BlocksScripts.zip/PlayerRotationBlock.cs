﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerRotationBlock : Block
{
    [SerializeField]
    TMPro.TMP_InputField inputField;
    GameObject player;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SetPlayer(GameObject _player)
    {
        player = _player;
    }

    public override void Play()
    {
        if (inputField.text.Trim() != "")
            player.transform.localRotation = Quaternion.Euler(player.transform.localRotation.eulerAngles.x, player.transform.localRotation.eulerAngles.y, player.transform.localRotation.eulerAngles.z + float.Parse(inputField.text.Trim()));
    }
}
